# Biografia básica de Bruno Pires de Carvalho

### O Início
No primeiro domingo de Junho de 1993, com os olhos claros e azuis como o céu, conforme diz a própria mãe, e com mais de 5 quilos de peso, nasce Bruno, cujo o nome foi escolhido dentre vários outros nomes através de um sorteio, feito pelo irmão mais velho, Marcos Antonio, e sua mãe Katia.
---
### O Agora
Simples e criativo, morador de Nova Friburgo, Rio de Janeiro, Bruno busca se envolver e se especializar na área de TI, pois além de ser uma área em crescimento constante, também é uma área que falta muitos profissionais realmente qualificados.